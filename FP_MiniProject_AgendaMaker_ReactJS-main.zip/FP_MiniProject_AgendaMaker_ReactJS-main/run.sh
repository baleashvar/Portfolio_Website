cd ReactJS/
npm start
